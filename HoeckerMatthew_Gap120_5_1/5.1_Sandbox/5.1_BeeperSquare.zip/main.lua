require "Karl"

function main()	

	turnoff();		
end			